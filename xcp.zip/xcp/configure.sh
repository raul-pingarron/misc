#!/bin/bash
# This is configuration script for file analytics which does the following
#     1. Installation - Fresh install
#     2. Uninstallation - Uninstalls already installed components by this script
#     3. Repair setup - Fix issues with setups
# Pre-requisite: To run this script you have to be in the xcp folder after you extract
# tgz file. Do not alter any folder after you extract tgz file

# Check if XCP license is activated. If not, it will run activation command
# we need to have xcp.ini, license and log folder available before we start installation
check_if_xcp_activated()
{
  if [ ! -e /opt/NetApp/xFiles/xcp/license ]; then
    echo "# XCP license file not found" | tee -a installation.log
    echo "# Download license file from https://xcp.netapp.com/ and run xcp activate. Exiting!" | tee -a installation.log
    exit 0;
  fi
  if [ ! -e /opt/NetApp/xFiles/xcp/xcp.ini ]; then
    echo "# Activating XCP license" | tee -a installation.log
    setsid ./linux/xcp activate
  fi
}

isInifileValid(){
    if [ -e /opt/NetApp/xFiles/xcp/xcp.ini ]
    then
       ## declare an array variablu
       declare -a arr=("db_password" "db_port = 5432" "db_host = 127.0.0.1" "db_user = central" "db_name = xcp_cmdb" "agent_id" "stdout_file_path = /opt/NetApp/xFiles/xcp/xcpfalogs/xcp_stdout.log" "stderr_file_path = /opt/NetApp/xFiles/xcp/xcpfalogs/xcp_stderr.log" "pid_file_path = /opt/NetApp/xFiles/xcp/xcp.pid" "log_file_path = /opt/NetApp/xFiles/xcp/xcpfalogs/xcp_out.log")

       ## Loop through the above array to find whether xcp.ini file is updated
       for i in "${arr[@]}"
        do
         case `grep "${i}" /opt/NetApp/xFiles/xcp/xcp.ini >/dev/null; echo $?` in
         0)
           # if security headers are found, amd services are installed, just start httpd service again
           echo "${i} found in xcp.ini file." >> installation.log
         ;;
         1)
           echo "${i} entry not found in xcp.ini file" >> installation.log
           echo "Client system is not configured. If you have already configured the client system, choose the option for rebuilding the ini file."
           break;
         ;;
         *)
           echo "Error occurred while checking for entry of ${i} in ini file."| tee -a installation.log
           break
         ;;
         esac
        done
    else
        echo "No xcp.ini file found." >> installation.log
    fi
}


# Check if xcp is running while configuring
# XCP service should be stopped while configuring system
check_if_xcp_is_running()
{
  echo "# Checking if XCP service is running"
  x=`ps -ef | grep xcp | wc -l`
  ps -ef | grep xcp |tee -a installation.log > /dev/null 2>&1
  if [[ $x -gt 1 ]]
  then
    echo "# WARNING: XCP process is already running on this system."| tee -a installation.log
    echo -e ''$_{1..80}'\b_'
    echo ""
    echo " $(ps -ef | grep xcp | grep -v grep) "
    echo -e ''$_{1..80}'\b_'
    echo ""
    echo "# Any running jobs will be killed abruptly if you stop xcp"
    read -p "# Do you want to stop XCP service: (yes/no):" choice
    case $choice in [nN][oO]|[nN])
        exit
      ;;
      [yY][eE][sS]|[yY])
        # Check if it is a service
        status="`systemctl | grep xcp.service | awk '{print $4}'`"
        if [[ "$status" == "running" ]]
        then
          service xcp stop
        fi
        # check if it is an old xcp process
        for pid in `ps -ef | grep "xcp --listen" |grep -v grep | awk '{print $2}'` ; do kill -9 $pid ; done
        # To clear defunct processes created as a result of termination of process using ctrl + Z
        for pid in `ps T | grep 'configure.sh' |grep -v grep | awk '{ if ($3 == "T") print $1 }'` ; do kill -9 $pid ; done
      ;;
      *)
        echo "# Invalid choice. Exiting !"  >> installation.log 2>&1
        exit
      ;;
    esac
  else
      echo 'No XCP services are running.'
  fi
}

# Install and configure PostgreSQL
install_configure_postgres()
{
  mkdir -p /var/run/postgresql
  # Method to install postgres
  echo -e ''$_{1..80}'\b-'
  echo "                                  Setting up Postgres                                        "
  echo -e ''$_{1..80}'\b-'
  echo "# Checking if postgres is installed"
  declare regex="active \(running\)"
  STATUS="$(service postgresql status)"
  if [[ "${STATUS}" =~ $regex ]];then
      echo "# Postgres service is already running" | tee -a installation.log
      return
  fi
  # Check if postgres is installed
  pkg="postgresql-server"
  if rpm -q $pkg
    then
      echo "# PostgreSQL is already installed" | tee -a installation.log
  else
      echo "# Installing PostgreSQL..." | tee -a installation.log
      yum -y install postgresql-server >> installation.log  2>&1
  fi
  echo "# Initializing database ...." | tee -a installation.log
  # Check if DB is initialized
  postgresql-setup initdb  >> installation.log  2>&1
  chown -R postgres:postgres /var/run/postgresql  >> installation.log 2>&1
  systemctl enable postgresql.service  >> installation.log 2>&1
  systemctl start postgresql.service  >> installation.log 2>&1
  # Method to configure postgres
  echo "# Configuring postgres ..." | tee -a installation.log
  file_content=$( cat /var/lib/pgsql/data/pg_hba.conf )
  declare regex="host\s+all\s+all\s+127\.0\.0\.1\/32\s+ident"
  grep -qxF "host    all             all             0.0.0.0/0            password"  /var/lib/pgsql/data/pg_hba.conf || echo "host    all             all             0.0.0.0/0            password"  | tee -a /var/lib/pgsql/data/pg_hba.conf > /dev/null 2>&1
  if [[ " $file_content " =~ ${regex} ]];then
      echo "# Updating pg_hba.conf file"
      sed -i -r 's/^(host\s+all\s+all\s+127\.0\.0\.1\/32\s+ident).*/#\1/' /var/lib/pgsql/data/pg_hba.conf
  fi

  file_content=$( cat /var/lib/pgsql/data/postgresql.conf )
  declare regex1="listen_addresses='\*'"
  declare regex2="unix_socket_directories='\/var\/run\/postgresql'"
  echo "# Updating postgresql.conf file"
  if [[ ! " $file_content " =~ ${regex1} ]];then
      echo "listen_addresses='*'" | tee -a /var/lib/pgsql/data/postgresql.conf > /dev/null 2>&1
  fi
  if [[ ! " $file_content " =~ ${regex2} ]];then
    echo "unix_socket_directories = '/var/run/postgresql'"  | tee -a /var/lib/pgsql/data/postgresql.conf > /dev/null 2>&1
  fi
  systemctl restart postgresql.service  >> installation.log 2>&1
  declare regex="active \(running\)"
  service postgresql status  >> installation.log 2>&1
  sleep 2
  STATUS="$(service postgresql status)"
  if [[ "${STATUS}" =~ $regex ]];then
    echo "# Postgres service is running"| tee -a installation.log
    return
  else
      echo "# Error in starting postgres ..." | tee -a installation.log
      exit 0
  fi
  systemctl enable postgresql  >> installation.log 2>&1
}

# Uninstall postgres
uninstall_postgres()
{
  # Method to uninstall postgres
  pkg="postgresql-server"
	if rpm -q $pkg
    then
      loop=1
      while [ $loop ] ;
        do
          read -p "# WARNING: This will remove Postgres. Continue? (yes/no):" choice
          case $choice in [nN][oO]|[nN])
            break
            ;;
            [yY][eE][sS]|[yY])
              echo "# Uninstalling Postgres..." | tee -a installation.log
              yum -y remove postgresql* >> installation.log 2>&1
              break
            ;;
            *)
              echo " Invalid choice. Please type yes or no"
            ;;
          esac
      done
  else
      echo "# ERROR: Postgres is not installed." | tee -a installation.log
      return
  fi
  loop=1
  if [ -d "/var/lib/pgsql" ]
    then
      echo "# Database initialization path is /var/lib/pgsql/data"
      while [ $loop ] ;
      do
          read -p "# WARNING: This will remove the above directory. Continue? : (yes/no):" choice
          case $choice in [nN][oO]|[nN])
              break
            ;;
            [yY][eE][sS]|[yY])
              rm -rf /var/lib/pgsql >> installation.log 2>&1
              break
            ;;
            *)
              echo "# Invalid choice. Please type yes or no"
            ;;
          esac
      done
  fi
  echo "# Postgres uninstallation successful" | tee -a installation.log
}

# Install httpd
install_httpd()
{
  mkdir -p /run/httpd
  # Method to install httpd
  echo -e ''$_{1..80}'\b-'
  echo "                                  Setting up httpd                                        "
  echo -e ''$_{1..80}'\b-'
  echo "# Checking if httpd is installed"
  pkg1="httpd"
  if rpm -q $pkg1
    then
      # httpd installed but httpd.conf file is missing
      if [ -f  /etc/httpd/conf/httpd.conf ]
        then
          echo "# HTTPD is already installed... "| tee -a installation.log
      else
        echo "# Could not find httpd.conf file. Re-installing httpd service..."| tee -a installation.log
          # merely doing an install doesnt create httpd.conf file. Therefore uninstalling and reinstalling httpd
          yum -y remove httpd* >> installation.log 2>&1
          yum -y install httpd --disablerepo=jbappplatform-6-* >> installation.log 2>&1
      fi
  else
      echo "# Installing HTTPD..."| tee -a installation.log
      yum -y install httpd --disablerepo=jbappplatform-6-* >> installation.log 2>&1
  fi
  isSecurityHeaderPresent
}


isSecurityHeaderPresent(){
      # check whether security fixes are present in httpd.conf file
      case `grep -Fx "#security fixes" /etc/httpd/conf/httpd.conf >/dev/null; echo $?` in
      0)
        # if security headers are found, amd services are installed, just start httpd service again
        systemctl start httpd
      ;;
      1)
        # security headers not found
        setSecurityHeaders
      ;;
      *)
        echo 'Error occurred while setting security Headers.Please contact technical support.' | tee -a installation.log
      ;;
      esac
}


setSecurityHeaders(){
  echo "# Updating httpd.conf file ... "
  file_content=$( cat /etc/httpd/conf/httpd.conf )
  host_ip=$(ip route get 8.8.8.8 | sed -n '/src/{s/.*src *\([^ ]*\).*/\1/p;q}')

  declare regex1="xcp\/index\.html"
  if [[ ! " $file_content " =~ ${regex1} ]];then
      echo '
#security fixes
#Set the correct Char set so no need to set it per page.
AddDefaultCharset utf-8

#for css, js, etc.
AddCharset utf-8 .htm .html .js .css .woff2

#Load the headers module
LoadModule headers_module modules/mod_headers.so
<IfModule mod_headers.c>
<Directory />
AuthType Digest
Anonymous_NoUserID off
Anonymous_MustGiveEmail on
Anonymous_VerifyEmail on
Anonymous_LogEmail on

RewriteCond %{REQUEST_METHOD} ^(TRACE|TRACK)
Header set Cache-Control "no-cache, no-store, must-revalidate,max-age=0"
Header always set X-XSS-Protection "1; mode=block"
Header always set x-Frame-Options "SAMEORIGIN"
Header always set X-Content-Type-Options "nosniff"
Header always set Strict-Transport-Security "max-age=31536000; includeSubDom                                                                                                                                                             ains"
Header always set Content-Security-Policy "connect-src '"https://${host_ip}:5030/"' ;"
Header always set Referrer-Policy "strict-origin"
</Directory>
</IfModule>

# fixing browser cache directive
<filesMatch ".(ico|pdf|flv|jpg|jpeg|png|gif|js|css|swf)$">
    Header set Cache-Control "no-cache, no-store, must-revalidate,max-age=0"
    Header set Pragma "no-cache"
    Header set Expires "0"
</filesMatch>

# web server to avoid having it announce its own details
ServerSignature Off
ServerTokens Prod

<Directory "/var/www/html/xcp">
AuthType Digest
Anonymous_NoUserID off
Anonymous_MustGiveEmail on
Anonymous_VerifyEmail on
Anonymous_LogEmail on

Header set Cache-Control "no-cache, no-store, must-revalidate,max-age=0"
Require all granted
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]
RewriteRule ^ index.html [L]
RewriteEngine On
RewriteCond %{REQUEST_METHOD} ^(TRACE|TRACK)
RewriteRule .* - [F]

Header set Cache-Control "no-cache, no-store, must-revalidate,max-age=0"
Header always set X-XSS-Protection "1; mode=block"
Header always set x-Frame-Options "SAMEORIGIN"
Header always set X-Content-Type-Options "nosniff"
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
Header always set Content-Security-Policy "connect-src '"https://${host_ip}:5030/"' ;"
Header always set Referrer-Policy "strict-origin"

</Directory> '| tee -a /etc/httpd/conf/httpd.conf > /dev/null 2>&1
  fi

  sed -i -e '/^<Directory \/>/aRewriteEngine On\nRewriteCond %{REQUEST_METHOD} ^(TRACE|TRACK)\nAuthType Digest\nAnonymous_NoUserID off\nAnonymous_MustGiveEmail on\nAnonymous_VerifyEmail on\nAnonymous_LogEmail on\nHeader set Cache-Control "no-cache, no-store, must-revalidate,max-age=0"\nHeader always set X-XSS-Protection "1; mode=block"\nHeader always set x-Frame-Options "SAMEORIGIN"\nHeader always set X-Content-Type-Options "nosniff"\nHeader always set Strict-Transport-Security "max-age=31536000; includeSubDomains"\nHeader always set Content-Security-Policy "connect-src '"https://${host_ip}:5030/"' ;"\nHeader always set Referrer-Policy "strict-origin"'  /etc/httpd/conf/httpd.conf
  # diable apache welcome page
  sed -i.bak -e "/#/! s/403/404/g" /etc/httpd/conf.d/welcome.conf > /dev/null 2>&1
  sed -i.bak -e "/#/! s/.*Directory/#&/" /etc/httpd/conf.d/welcome.conf > /dev/null 2>&1
  sed -i.bak -e "/#/! s/.*AllowOverride/#&/" /etc/httpd/conf.d/welcome.conf > /dev/null 2>&1
  sed -i.bak -e "/#/! s/.*Require/#&/" /etc/httpd/conf.d/welcome.conf > /dev/null 2>&1
  systemctl restart httpd >> installation.log 2>&1
  systemctl enable httpd >> installation.log 2>&1
  chkconfig httpd on >> installation.log 2>&1
  service httpd status >> installation.log 2>&1
  sleep 2
  declare regex="active \(running\)"
  STATUS="$(service httpd status)"
  if [[ "${STATUS}" =~ $regex ]];then
    echo "# Httpd service is running"| tee -a installation.log
  else
    echo "# Error: Httpd services failed to start"| tee -a installation.log
    return
  fi
}

# Uninstall httpd
uninstall_httpd()
{
  # Method to uninstall httpd
  loop=1
  pkg="httpd"
  if rpm -q $pkg
    then
      while [ $loop ] ;
      do
          read -p "# WARNING: This will remove httpd. Continue? (yes/no):" choice
          case $choice in [nN][oO]|[nN])
                break
              ;;
              [yY][eE][sS]|[yY])
                echo "# Uninstalling httpd ..."| tee -a installation.log
                yum -y remove httpd* >> installation.log 2>&1
                break
              ;;
              *)
                echo " Invalid choice. Please type yes or no"
             ;;
          esac
      done
  else
      echo "# ERROR: httpd service is not installed"| tee -a installation.log
      return
  fi
}

# Configure https
configure_https()
{
  # Method to configure https
  echo -e ''$_{1..80}'\b-'
  echo "                                  Setting up https                          "
  echo -e ''$_{1..80}'\b-'
  pkg1="mod_ssl"
  if rpm -q $pkg1
    then
      echo "# Https is already installed... "| tee -a installation.log
      return
  else
      echo "# Installing HTTPs...It will take 3-5 minutes to configure" | tee -a installation.log
      yum install httpd mod_ssl -y >> installation.log 2>&1
      systemctl enable httpd && systemctl start httpd  >> installation.log 2>&1
      host_ip=$(ip route get 8.8.8.8 | sed -n '/src/{s/.*src *\([^ ]*\).*/\1/p;q}')
      openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /opt/NetApp/xFiles/xcp/server.key -out /opt/NetApp/xFiles/xcp/server.crt -subj "/C=XX/ST=X/L=X/O=Netapp/OU=XCP/CN=${host_ip}"> /dev/null 2>&1 |tee -a installation.log
      sed -i.bak '/^SSLCertificateFile /c\SSLCertificateFile /opt/NetApp/xFiles/xcp/server.crt' /etc/httpd/conf.d/ssl.conf
      sed -i.bak '/^SSLCertificateKeyFile /c\SSLCertificateKeyFile /opt/NetApp/xFiles/xcp/server.key' /etc/httpd/conf.d/ssl.conf
  fi

  #Fix ssl related errors
  sed -i.bak -e '/#/! s/SSLProtocol all -SSLv2 -SSLv3/#&/' /etc/httpd/conf.d/ssl.conf > /dev/null 2>&1
  sed -i.bak -e '/#/! s/SSLCipherSuite HIGH:3DES:!aNULL:!MD5:!SEED:!IDEA/#&/' /etc/httpd/conf.d/ssl.conf > /dev/null 2>&1

  grep -qxF 'SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1' /etc/httpd/conf.d/ssl.conf || echo  "SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1" | tee -a /etc/httpd/conf.d/ssl.conf > /dev/null 2>&1
  grep -qxF "SSLCipherSuite HIGH:"'!'"aNULL:"'!'"MD5:"'!'"3DES" /etc/httpd/conf.d/ssl.conf || echo "SSLCipherSuite HIGH:"'!'"aNULL:"'!'"MD5:"'!'"3DES"| tee -a /etc/httpd/conf.d/ssl.conf > /dev/null 2>&1
  grep -qxF 'SSLHonorCipherOrder on' /etc/httpd/conf.d/ssl.conf || echo "SSLHonorCipherOrder on"| tee -a /etc/httpd/conf.d/ssl.conf > /dev/null 2>&1
  systemctl restart httpd >> installation.log 2>&1
}

# Create xcp linux service
create_xcp_service()
{
  #We need to start xcp as service using systemd
  if [ ! -e /lib/systemd/system/xcp.service ]
  then
    echo "# Creating XCP service ..." | tee -a installation.log
    cp ./linux/xcp /usr/bin/xcp
    echo "
[Unit]
Description=XCP systemd service.
After=httpd

[Service]
Type=simple
ExecStart=/bin/bash -ce \"exec /usr/bin/xcp --listen >> /opt/NetApp/xFiles/xcp/xcpfalogs/xcp_console.log 2>&1\"

[Install]
WantedBy=multi-user.target
" |tee -a /lib/systemd/system/xcp.service  > /dev/null 2>&1
    systemctl daemon-reload >> installation.log 2>&1
    yes | cp /lib/systemd/system/xcp.service /etc/systemd/system/xcp.service
    chmod 644 /etc/systemd/system/xcp.service
    systemctl daemon-reload >> installation.log 2>&1
    systemctl start xcp >> installation.log 2>&1
    systemctl enable xcp >> installation.log 2>&1

    declare regex="active \(running\)"
    STATUS="$(service xcp status)"
    sleep 2
    if [[ "${STATUS}" =~ $regex ]];then
      echo "# XCP service started successfully"
    else
      echo "# Error: Failed to start XCP services" | tee -a installation.log
      echo "# Please refer the troubleshooting section of XCP File Analytics in the user guide."
      echo "# If problem persists, contact XCP Customer support."
      echo '# To start XCP service manually, use "systemctl start xcp" command'
      exit
    fi
  else
    declare regex="active \(running\)"
    STATUS="$(service xcp status)"
    if [[ "${STATUS}" =~ $regex ]];then
      echo "# XCP service started successfully"
    else
      systemctl daemon-reload >> installation.log 2>&1
      systemctl start xcp >> installation.log 2>&1
      sleep 2
      declare regex="active \(running\)"
      STATUS="$(service xcp status)"
      if [[ "${STATUS}" =~ $regex ]];then
        echo "# XCP service started successfully"
      else
        echo "# Error: Failed to start XCP services." | tee -a installation.log
        echo "# Please refer the troubleshooting section of XCP File Analytic in the user guide."
        echo "# If problem persists, contact XCP Customer support."
        echo '# To start XCP service manually, use "systemctl start xcp" command'
        exit
      fi
    fi
  fi
  systemctl enable xcp >> installation.log 2>&1
}

# Delete xcp serivce which is created
delete_xcp_service()
{
  loop=1
  while [ $loop ] ;
    do
      read -p "# WARNING: This will remove XCP service. Continue? (yes/no):" choice
        case $choice in [nN][oO]|[nN])
            break
          ;;
          [yY][eE][sS]|[yY])
            echo "# Deleting XCP service ..."
            status="`systemctl | grep xcp.service | awk '{print $4}'`"
            if [[ "$status" == "running" ]]
            then
              service xcp stop >> installation.log 2>&1
            fi
            rm -f /lib/systemd/system/xcp.service
            rm -f /etc/systemd/system/xcp.service
            break
          ;;
          *)
            echo " Invalid choice. Please type yes or no"
          ;;
        esac
    done
}

# Starting xcp services
starting_xcp_service()
{
  echo -e ''$_{1..80}'\b-'
  echo "                                  Configuring XCP                          "
  echo -e ''$_{1..80}'\b-'
  echo "# Copying XCP files....."
  if [ ! -d /var/www/html/xcp_backup  -a -d /var/www/html/xcp ]
    then
      echo "# Taking backup of xcp folder /var/www/html/xcp in /var/www/html/xcp_backup"
      mv /var/www/html/xcp /var/www/html/xcp_backup |tee -a installation.log > /dev/null 2>&1
  fi
  cp -f ./linux/xcp /usr/bin/xcp >> installation.log 2>&1
  cp -r ./xcp_gui/xcp /var/www/html >> installation.log 2>&1
  echo "NOTE:"
  echo "If you are running configuration for first time, select option 1."
  echo "If you are upgrading, select option 0."

  ./linux/xcp --configure
  if [ $? != 0 ];
  then
    exit
  fi
  echo -e ''$_{1..80}'\b-'
  echo "                                 Starting xcp service                         "
  echo -e ''$_{1..80}'\b-'
  create_xcp_service
  echo " $(ps -ef | grep xcp | grep -v grep) "
  sleep 2
  if pgrep xcp |tee -a installation.log > /dev/null 2>&1
  then
    echo -e ''$_{1..80}'\b-'
    echo -e ''$_{1..80}'\b-'
    echo 'XCP File analytics is configured successfully' | tee -a installation.log
    echo 'To start XCP service manually, use "systemctl start xcp" command'
    echo ""
    host_ip=$(ip route get 8.8.8.8 | sed -n '/src/{s/.*src *\([^ ]*\).*/\1/p;q}')
    echo " Use following link and login as 'admin' user for GUI access"
    echo "https://$host_ip/xcp"
    echo -e ''$_{1..80}'\b-'
  else
    echo "# Failed to start XCP service" | tee -a installation.log
  fi
}


configureAndStartXCP(){
  ./linux/xcp --configure
  systemctl start xcp >> installation.log 2>&1
  sleep 2
  STATUS=`systemctl is-active xcp`
  if [[ "${STATUS}" == "active" ]];then
    echo "# XCP service started successfully" | tee -a installation.log
  else
    echo "# Error: Failed to start XCP services" | tee -a installation.log
    echo "# Please refer the troubleshooting section of XCP File Analytics in the user guide."
    echo "# If problem persists, contact XCP Customer support."
    echo '# To start XCP service manually, use "systemctl start xcp" command'
    exit
  fi
}

# Repair setup which are failed
repair_setup()
{
  echo -e ''$_{1..80}'\b-'
  echo "                                  Repair setup                          "
  echo -e ''$_{1..80}'\b-'
  echo "# Note: Repair setup will only start services if they are stopped"
  echo "# Checking postgres server"
  declare regex="active \(running\)"
  STATUS="$(service postgresql status)"
  postGresOK=0
  if [[ "${STATUS}" =~ $regex ]];then
    postGresOK=1
    echo "# Postgres service is running" | tee -a installation.log
  else
      mkdir -p /var/run/postgresql
      chown -R postgres:postgres /var/run/postgresql
      service postgresql restart >> installation.log 2>&1
      STATUS="$(service postgresql status)"
      postGresOK=0
      if [[ "${STATUS}" =~ $regex ]];then
        echo "# Postgres service is running " | tee -a installation.log
        postGresOK=1
      else
        postGresOK=0
        echo "# Error is starting postgres." | tee -a installation.log
      fi
  fi
  echo "# Checking httpd"
  declare regex="active \(running\)"
  STATUS="$(service httpd status)"
  httpdOK=0
  if [[ "${STATUS}" =~ $regex ]];then
    httpdOK=1
    echo "# Httpd service is running" | tee -a installation.log
  else
      httpdOK=0
      mkdir -p /run/httpd
      service httpd restart >> installation.log 2>&1
      nrepeat=0
      while [ $nrepeat -lt 2 ]
      do
          sleep 2
          STATUS="$(service httpd status)"
          if [[ "${STATUS}" =~ $regex ]];then
            httpdOK=1
            echo "# Httpd service is running" | tee -a installation.log
            break
          else
            httpdOK=0
            echo "Attempt ${nrepeat}:"
            echo "# Error is starting httpd ." | tee -a installation.log
          fi
          ((nrepeat++))
      done
  fi
  echo "# Checking certificates"
  if [ -e  /opt/NetApp/xFiles/xcp/server.crt -a  -e /opt/NetApp/xFiles/xcp/server.key ]
  then
    echo "# Certificates are present."
  else
    echo "# Copying certificates ..."
    cp -pr /etc/pki/tls/certs/localhost.crt /opt/NetApp/xFiles/xcp/server.crt
    cp  -pr /etc/pki/tls/private/localhost.key /opt/NetApp/xFiles/xcp/server.key
  fi
  echo "# Checking XCP file analytics"
  if [ -d /var/www/html/xcp ]
    then
      echo "# XCP GUI files are available in /var/www/html/xcp" | tee -a installation.log
  else
      echo "# Copying XCP files" | tee -a installation.log
      mv /var/www/html/xcp /var/www/html/xcp_backup >> installation.log  2>&1
  fi

  if [ "$postGresOK" -eq 1 ] && [ "$httpdOK" -eq 1 ]
  then
    echo "NOTE:"
    echo "Postgres and HTTPD services are running successfully. Please enter 0 to quit and start XCP service" | tee -a installation.log
  elif [ "$postGresOK" -eq 0 ] && [ "$httpdOK" -eq 1 ]
  then
    echo "NOTE:"
    echo "Refer XCP File Analytics troubleshooting section in the document for addressing failure in starting Postgres service"| tee -a installation.log
    exit
  elif [ "$postGresOK" -eq 1 ] && [ "$httpdOK" -eq 0 ]
  then
    echo "NOTE:"
    echo "Refer XCP File Analytics troubleshooting section in the document for addressing failure in starting HTTPD service"| tee -a installation.log
    exit
  else
    echo "NOTE:"
    echo "Refer XCP File Analytics troubleshooting section in the document for addressing failure in starting Postgres and HTTPD service" | tee -a installation.log
    exit
  fi
  isInifileValid
  configureAndStartXCP
  host_ip=$(ip route get 8.8.8.8 | sed -n '/src/{s/.*src *\([^ ]*\).*/\1/p;q}')
  echo -e ''$_{1..80}'\b-'
  echo -e ''$_{1..80}'\b-'
  echo 'XCP File analytics is configured successfully'
  echo 'To start XCP service manually, use "systemctl start xcp" command'
  echo ""
  echo " Use following link and login as 'admin' user from GUI access"
  echo "https://$host_ip/xcp"
  echo -e ''$_{1..80}'\b-'
}

# Main menu for installation.
main_menu()
{
  xcpPackageVersion="1.6.3"
  xcpBinaryVersion=`./linux/xcp --version`
  echo "XCP Package version : ${xcpPackageVersion}" >> installation.log
  echo "XCP Binary version : ${xcpBinaryVersion}" >> installation.log

  if [[ $xcpBinaryVersion != *"1.6.3"* ]];
   then
    echo "Package version and XCP Linux binary version do not match. Please use the same version of GUI and the Linux binary" | tee -a installation.log
    exit
  fi
  echo "#########  Configuring XCP File Analytics  #########" | tee -a installation.log > /dev/null 2>&1
  hostnamectl | grep 'Operating System' |tee -a installation.log > /dev/null 2>&1
  sudo -l | sudo tee -a installation.log > /dev/null 2>&1
  # Check if xcp is running. Stop configuration if it is running.
  check_if_xcp_is_running
  echo ""
  echo "Menu Help:"
  echo "# Install/ Upgrade"
  echo "#   Installs PostgreSQL and httpd if not installed and does setup for XCP File Analytics"
  echo "#   Upgrade takes a backup of xcp folder under /var/www/html/ to xcp_backup"
  echo "# Repair/ Manage"
  echo "#   Repair restarts PostgreSQL database, httpd and XCP services in case if any of them are stopped."
  echo "#   Manage allows you to change password and rebuild xcp.ini file for existing XCP instance"
  echo "# Cleanup - Uninstalls PostgreSQL and httpd."
  echo "# Update security headers for Windows agent"
  echo "#   After successfully configuring the Windows agent, use this option to update its IP"
  echo "#   in http server. Updating SMB agent IP is mandatory to access configured Windows agent in the GUI"
  echo ""
  echo "1. Installation/Upgrade"
  echo "2. Repair/Manage"
  echo "3. Cleanup"
  echo "4. Update XCP windows agent IP"
  echo "0. Exit"
  echo ""
  read -p "Please select the option from the menu [0-4]: " option

  if [ "$option" = "0" ]
    then
      echo "# Selected option 0 ... Exiting !" | tee -a installation.log
      exit 0;
  elif [ "$option" = "1"  ]
    then
      check_if_xcp_activated
      install_configure_postgres
      install_httpd
      configure_https
      starting_xcp_service
      isInifileValid

  elif [ "$option" = "2"  ]
    then
      check_if_xcp_activated
      check_if_xcp_is_running
      repair_setup
  elif [ "$option" = "3"  ]
    then
      loop=1
      while [ $loop ] ;
      do
          read -p "# WARNING:  This will start uninstallation. Continue? (yes/no):" choice
          case $choice in [nN][oO]|[nN])
              echo "# Uninstallation cancelled by user!"
              break
            ;;
            [yY][eE][sS]|[yY])
              uninstall_postgres
              uninstall_httpd
              delete_xcp_service
              break
            ;;
            *)
              echo "# Invalid choice. Please type yes or no"
            ;;
          esac
      done
      main_menu
  elif [ "$option" = "4"  ]
    then
       if [ -f  /etc/httpd/conf/httpd.conf ]
          then
            read -p "Enter valid IPv4 address of Windows agent where XCP File Analytics is configured: " windows_ip_addr
            STATUS="$(ipcalc -s -c ${windows_ip_addr})"
            if [ $?  -eq  1 ]
              then
                echo "# Invalid IP address. Starting XCP service and Exiting !!!"
            else
              #valid IP
              systemctl stop httpd >> installation.log 2>&1
              # add security headers
              host_ip=$(ip route get 8.8.8.8 | sed -n '/src/{s/.*src *\([^ ]*\).*/\1/p;q}')
              sed -i.bak '/^Header always set Content-Security-Policy /c\Header always set Content-Security-Policy "connect-src '"https://${host_ip}:5030/"' '"https://${windows_ip_addr}:5030/"';"' /etc/httpd/conf/httpd.conf
              echo 'Successfully updated Windows agent.'
              echo ""
              systemctl restart httpd >> installation.log 2>&1
            fi
            systemctl start xcp >> installation.log 2>&1
            sleep 2
            STATUS=`systemctl is-active xcp`
            if [[ "${STATUS}" == "active" ]];then
              echo "# XCP service started successfully"
            else
              echo "# Error: Failed to start XCP services" | tee -a installation.log
              echo "# Please refer the troubleshooting section of XCP File Analytics in the user guide."
              echo "# If problem persists, contact XCP Customer support."
              echo '# To start XCP service manually, use "systemctl start xcp" command'
            fi
            exit
        else
          # when user selects option 4 before installation
          echo 'Please complete the installation process before selecting this option. '
          main_menu
        fi
  else
    echo "# ERROR: Allowed inputs are [0-3]"
    echo ""
    main_menu
  fi

}


#check whether working dir of user is */xcp
p="`pwd`"
if [[ "$p" == *"/xcp" ]]
  then
    date >> installation.log 2>&1
    echo -e ''$_{1..80}'\b-'
    echo "                                  XCP CONFIGURATION SCRIPT                                        "
    echo -e ''$_{1..80}'\b-'
    main_menu
    exit 0
else
  echo 'Note: To run this script please make sure that you are inside xcp folder after you extract the tar file' | tee -a installation.log
  exit 0
fi
